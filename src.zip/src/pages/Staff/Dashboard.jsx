const DashboardPage = () =>{
return(
    <>
    <h1>Trang Báo cáo thống kê</h1>
    </>
)
};
export default DashboardPage;