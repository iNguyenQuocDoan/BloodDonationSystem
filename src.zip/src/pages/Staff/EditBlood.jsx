const EditBloodPage = () =>{
return(
    <>
    <h1>Trang chỉnh sửa nhóm máu</h1>
    </>
)
};
export default EditBloodPage;