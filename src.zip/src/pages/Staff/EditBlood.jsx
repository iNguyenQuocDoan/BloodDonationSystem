const EditBloodPage = () =>{
return(
    <>
    <h1>Trang quản lý danh sách hiến máu</h1>
    </>
)
};
export default EditBloodPage;