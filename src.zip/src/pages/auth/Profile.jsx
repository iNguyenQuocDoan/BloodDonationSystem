import { useEffect, useState } from "react";
import useApi from "../../hooks/useApi";

const ProfilePage = () => {
  const { getCurrentUser } = useApi();
  const [user, setUser] = useState(null);

  useEffect(() => {
    getCurrentUser()
      .then((res) => setUser(res.data))
      .catch(() => setUser(null));
  }, [getCurrentUser]);

  if (!user)
    return <div className="text-center py-8">Đang tải thông tin...</div>;

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-8 mt-10">
      <h2 className="text-2xl font-bold text-[#D32F2F] mb-6 text-center">
        Thông tin cá nhân
      </h2>
      <div className="space-y-4">
        <div>
          <strong>Họ tên:</strong> {user.user_name}
        </div>
        <div>
          <strong>Email:</strong> {user.email}
        </div>
        <div>
          <strong>Số điện thoại:</strong> {user.phone || "Chưa cập nhật"}
        </div>
        <div>
          <strong>Ngày sinh:</strong> {user.date_of_birth || "Chưa cập nhật"}
        </div>
        {/* Thêm các trường khác nếu cần */}
      </div>
    </div>
  );
};

export default ProfilePage;
