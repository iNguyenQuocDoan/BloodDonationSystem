import { Link } from "react-router-dom"
import { AiOutlineEyeInvisible } from "react-icons/ai";
import { AiOutlineEye } from "react-icons/ai";
import { useState } from "react";
export const RegisterPage = () => {
    return (
        <>
            Register Page
        </>
    )
}